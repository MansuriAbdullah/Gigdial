import asyncHandler from 'express-async-handler'; // Need to install this or use try-catch
import User from '../models/User.js';
import generateToken from '../utils/generateToken.js';

// I need to install express-async-handler or just use try/catch blocks.
// I'll stick to try-catch blocks to avoid extra dependency separate install for now, 
// OR I'll assume I can install it quickly. Actually, let's use standard try/catch to be dependency-lite or I can add it to package.json.
// Better yet, I'll validly use try/catch in the controller functions directly to keep it simple.
// Wait, asyncHandler is cleaner. I'll just npm install it.

// @desc    Auth user/set token
// @route   POST /api/users/auth
// @access  Public
const authUser = async (req, res) => {
    try {
        const { email, password } = req.body;

        const user = await User.findOne({ email });

        if (user && (await user.matchPassword(password))) {
            generateToken(res, user._id);

            res.status(200).json({
                _id: user._id,
                name: user.name,
                email: user.email,
                isAdmin: user.isAdmin,
                isProvider: user.isProvider
            });
        } else {
            res.status(401);
            throw new Error('Invalid email or password');
        }
    } catch (error) {
        res.status(401).json({ message: error.message });
    }
};

// @desc    Register a new user
// @route   POST /api/users
// @access  Public
const registerUser = async (req, res) => {
    try {
        const { name, email, password, phone, city, address, skills, isProvider } = req.body;

        const userExists = await User.findOne({ email });

        if (userExists) {
            res.status(400);
            throw new Error('User already exists');
        }

        let profileImage = '';
        let aadhaarCard = '';
        let panCard = '';

        if (req.files) {
            if (req.files.profileImage) {
                profileImage = req.files.profileImage[0].path;
            }
            if (req.files.aadhaarCard) {
                aadhaarCard = req.files.aadhaarCard[0].path;
            }
            if (req.files.panCard) {
                panCard = req.files.panCard[0].path;
            }
        }

        const user = await User.create({
            name,
            email,
            password,
            phone,
            city,
            address,
            skills: skills ? JSON.parse(skills) : [], // If sent as FormData, arrays might need parsing
            isProvider: isProvider === 'true' || isProvider === true, // FormData sends booleans as strings
            profileImage,
            aadhaarCard,
            panCard
        });

        if (user) {
            generateToken(res, user._id);
            res.status(201).json({
                _id: user._id,
                name: user.name,
                email: user.email,
                isAdmin: user.isAdmin,
                isProvider: user.isProvider,
                profileImage: user.profileImage
            });
        } else {
            res.status(400);
            throw new Error('Invalid user data');
        }
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};

// @desc    Logout user / clear cookie
// @route   POST /api/users/logout
// @access  Public
const logoutUser = (req, res) => {
    res.cookie('jwt', '', {
        httpOnly: true,
        expires: new Date(0),
    });
    res.status(200).json({ message: 'Logged out successfully' });
};

// @desc    Get user profile
// @route   GET /api/users/profile
// @access  Private
const getUserProfile = async (req, res) => {
    try {
        const user = await User.findById(req.user._id);

        if (user) {
            res.status(200).json({
                _id: user._id,
                name: user.name,
                email: user.email,
                isAdmin: user.isAdmin,
                isProvider: user.isProvider
            });
        } else {
            res.status(404);
            throw new Error('User not found');
        }
    } catch (error) {
        res.status(404).json({ message: error.message });
    }
};

// @desc    Update user profile
// @route   PUT /api/users/profile
// @access  Private
const updateUserProfile = async (req, res) => {
    try {
        const user = await User.findById(req.user._id);

        if (user) {
            user.name = req.body.name || user.name;
            user.email = req.body.email || user.email;

            if (req.body.password) {
                user.password = req.body.password;
            }

            const updatedUser = await user.save();

            res.status(200).json({
                _id: updatedUser._id,
                name: updatedUser.name,
                email: updatedUser.email,
                isAdmin: updatedUser.isAdmin
            });
        } else {
            res.status(404);
            throw new Error('User not found');
        }
    } catch (error) {
        res.status(404).json({ message: error.message });
    }
};

export {
    authUser,
    registerUser,
    logoutUser,
    getUserProfile,
    updateUserProfile,
};
